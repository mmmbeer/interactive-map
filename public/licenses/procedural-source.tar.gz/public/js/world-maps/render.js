import { landColor, drawLandPattern, drawDistrictPreview } from './planning-render.js';
import { traceShape } from '../geometry.js';
import { loadSymbols, drawSymbol } from './cartography-symbols.js';
import { planDecorations, biomeFor } from './decoration-plan.js';
import { hash } from './model.js';
import { drawRoads } from './road-render.js';
export const DRAGONSGATE={paper:'#eeeae1',water:'#91a6ad',ink:'#202421',terrain:'#d8dccb',roadWidth:1,treeDensity:1,texture:.35,roofDetail:false};
function random(seed) {let n=hash(seed);return ()=>{n+=0x6D2B79F5;let t=n;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};}
export async function renderFantasy(canvas,{map,trees=[]},settings=DRAGONSGATE,{edge=1200,signal,districts=false}={}) {
  const scale=Math.min(1,edge/Math.max(map.width,map.height));
  canvas.width=Math.round(map.width*scale);canvas.height=Math.round(map.height*scale);
  signal?.throwIfAborted();
  const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Your browser could not create the map image. Try a lower resolution.');
  const s={...DRAGONSGATE,...settings},unit=map.width/4096;
  const [symbols,marks]=await Promise.all([loadSymbols(s.ink,signal),planDecorations(map,{trees,treeDensity:s.treeDensity,signal})]);
  ctx.save();ctx.scale(canvas.width/map.width,canvas.height/map.height);ctx.lineJoin='round';ctx.lineCap='round';
  ctx.fillStyle=s.paper;ctx.fillRect(0,0,map.width,map.height);
  const layer=p=>biomeFor(p)||p.category==='terrain'?0:p.category==='water'?1:p.category==='street'?2:3;
  const places=[...map.locations].sort((a,b)=>layer(a)-layer(b)||a.id.localeCompare(b.id));
  let roadsDrawn=false;
  try {
    for(const [index,p] of places.entries()) {
      if(index%200===0){signal?.throwIfAborted();await new Promise(r=>setTimeout(r,0));}
      if(p.category==='street') {
        if(!roadsDrawn){drawRoads(ctx,places.filter(p=>p.category==='street'),unit,s.ink);roadsDrawn=true;}
        continue;
      }
      const kind=p.worldStyle?.kind,shape=p.shape;
      ctx.save();traceShape(ctx,p);
      if(p.category==='water') {
        ctx.fillStyle=s.water;ctx.strokeStyle='#596b6e';ctx.lineWidth=unit*.8;
        if(shape.kind==='polyline'){ctx.lineWidth=shape.width;ctx.strokeStyle=s.water;ctx.stroke();}
        else {ctx.fill('evenodd');ctx.stroke();}
      } else if((p.category==='terrain'||biomeFor(p))&&shape.kind==='polygon') {
        ctx.fillStyle=landColor(p,s);ctx.fill('evenodd');
        ctx.strokeStyle='#9c9c89';ctx.lineWidth=unit*.5;ctx.stroke();ctx.clip('evenodd');
        drawLandPattern(ctx,p,unit,s);
      } else if(kind==='building') {
        ctx.fillStyle=s.ink;ctx.strokeStyle='#111813';ctx.lineWidth=unit*.65;ctx.fill('evenodd');ctx.stroke();
        if(s.roofDetail) {
          ctx.clip('evenodd');const pts=shape.points,x=pts.reduce((n,p)=>n+p[0],0)/pts.length,y=pts.reduce((n,p)=>n+p[1],0)/pts.length;
          ctx.strokeStyle='#c1bfb0';ctx.lineWidth=unit*.7;
          ctx.beginPath();ctx.moveTo(x-9*unit,y-4*unit);ctx.lineTo(x+9*unit,y+4*unit);ctx.stroke();
        }
      }ctx.restore();
    }
    ctx.strokeStyle=s.ink;
    for(const [index,mark] of marks.entries()) {
      if(index%512===0){signal?.throwIfAborted();await new Promise(r=>setTimeout(r,0));}
      ctx.globalAlpha=mark.ambient?.6:['grass','ripples'].includes(mark.kind)?.6:.88;
      drawSymbol(ctx,symbols,mark);
    }
    ctx.globalAlpha=1;
    if(districts)drawDistrictPreview(ctx,map,scale);
    if(s.texture>0) {
      const rand=random(map.generationId);ctx.fillStyle='#252e27';ctx.globalAlpha=s.texture*.12;
      for(let i=0;i<14000;i++){const r=(.25+rand())*unit;ctx.fillRect(rand()*map.width,rand()*map.height,r,r);}
      ctx.globalAlpha=1;
    }
    const font=Math.max(12*unit,12/scale);ctx.font=`${font}px sans-serif`;
    const credit=map.worldImport?.preparedSource?'© OpenStreetMap contributors · Natural Earth · Protomaps':'© OpenStreetMap contributors · ODbL',textWidth=ctx.measureText(credit).width,pad=font*.6;
    ctx.fillStyle='rgba(255,255,250,.94)';ctx.fillRect(map.width-textWidth-pad*2,map.height-font-pad*1.5,textWidth+pad*2,font+pad*1.5);
    ctx.fillStyle='#273531';ctx.fillText(credit,map.width-textWidth-pad,map.height-pad*.6);
  } finally {ctx.restore();}
}
export function canvasBlob(canvas,type='image/png',signal) {
  return new Promise((resolve,reject)=>{
    const abort=()=>reject(signal.reason);
    if(signal?.aborted){abort();return;}
    signal?.addEventListener('abort',abort,{once:true});
    try {
      canvas.toBlob(blob=>{
        signal?.removeEventListener('abort',abort);
        if(signal?.aborted){abort();return;}
        blob?resolve(blob):reject(new Error('Could not encode the image. Try a lower resolution.'));
      },type,.9);
    }catch(e){signal?.removeEventListener('abort',abort);reject(e);}
  });
}
export function downloadBlob(blob,filename) {
  const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=filename;link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
}
export async function imageFiles(result,settings,signal) {
  const canvas=document.createElement('canvas'),thumbnailCanvas=document.createElement('canvas');
  try {
    await renderFantasy(canvas,result,settings,{edge:Math.max(result.map.width,result.map.height),signal});
    signal?.throwIfAborted();const image=await canvasBlob(canvas,'image/png',signal);
    thumbnailCanvas.width=360;thumbnailCanvas.height=Math.round(360*canvas.height/canvas.width);
    thumbnailCanvas.getContext('2d').drawImage(canvas,0,0,thumbnailCanvas.width,thumbnailCanvas.height);
    const thumbnail=await canvasBlob(thumbnailCanvas,'image/webp',signal);signal?.throwIfAborted();
    return {image,thumbnail};
  }finally{canvas.width=canvas.height=1;thumbnailCanvas.width=thumbnailCanvas.height=1;}
}
