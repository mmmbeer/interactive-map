// Reusable browser ES modules for a mapper/editor. See docs/mapping-tools.md.
// Import the full relative module tree; this file does not require a server API.
export { boundsFor, contains, ringContains, distanceToPath, traceShape, fillShape } from './geometry.js';
export { buildSpatialIndex, hitTest, matches, searchPlaces } from './spatial.js';
export { validateMap, categoryKeys } from './map-contract.js';
export { validateDistrictGeometry, hitTestDistrict, DistrictLayer } from './districts.js';
export { materializeMap, resolveLocation } from './generation/locations.js';
export { catalogFor, configFor, districtList, regionList, availableFields, versionFor } from './generation/config.js';
export { streams, choose, distribution, integer, sample, bank, words, combine } from './generation/helpers-v2.js';
export { recipe, eligible, matchingSources, uniqueChoices, priceFor } from './generation/detail-helpers-v1.js';
export { detailSources } from './generation/detail-sources-v1.js';
export { detailSections, detailFields } from './generation/details-v1.js';
export { migrateMap, serializeMap, newLocation, saveLocation } from './authoring/model.js';
export { MapStage } from './map-stage.js';
export { MapLabels } from './map-labels.js';

export { numberSites, siteNumbers, entrySections, isGeography } from './site-index.js';
export { StreetLayer, NumberLayer } from './map-overlays.js';
export { mapSheets } from './guide-maps.js';
export { createGuidePdf, mapImage } from './guide-pdf.js';
export { PdfDocument, loadPdfFonts } from './pdf-writer.js';
export { PdfFont } from './pdf-font.js';
export { guideCrop, guideEntryHTML } from './guide-entry.js';
export { districtColors, districtAdjacency, districtsAdjacent } from './district-colors.js';

export { buildRoadGraph } from './travel/graph.js';
export { roadRoute } from './travel/routing.js';
export { pathLength, calibration, formatDistance, travelTime } from './travel/geometry.js';

export { socialGraph, residentAt, householdAt, storiesAt } from './generation/social/index.js';
export { socialSources, scenarios } from './generation/social/sources.js';
export { householdTypes } from './generation/social/household-types.js';
export { compatibleProducts } from './generation/social/goods.js';

export { convertArea as convertWorldArea } from './world-maps/model.js';
export { queryFor as worldAreaQuery, fetchArea as fetchWorldArea } from './world-maps/source.js';
export { imageProjection, clipRing, clipLines } from './world-maps/geo.js';
export { renderFantasy, imageFiles, DRAGONSGATE } from './world-maps/render.js';

export { reconcileWater, upgradeWorldWater, resolveLocationId } from './world-maps/water.js';
export { enrichSettlement } from './world-maps/settlement-enrichment.js';
export { normalizeProfile as normalizeImportSettlement } from './world-maps/settlement-profile.js';
